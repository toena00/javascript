document.getElementById('message-btn').addEventListener('click', function() {
    document.getElementById('message').classList.toggle('hidden')});;